package provas.linguagemProgramacao1.provaLP1.exercicio2;

public class LimiteDeSaqueAtingido extends Exception{
    protected double limiteDeSaque;
    protected double saqueRequerido;

    public LimiteDeSaqueAtingido (double limiteDeSaque, double saqueRequerido) {
        super();
        this.limiteDeSaque = limiteDeSaque;
        this.saqueRequerido = saqueRequerido;
    }

    @Override
    public String toString() {
        return "Limite de saque diário atingido!";
    }
}
