package provas.linguagemProgramacao1.provaLP1.exercicio2;

public class SaldoEstourado extends Exception{
    protected double Saldo;
    protected double saqueRequerido;

    public SaldoEstourado(double saldo, double saqueRequerido) {
        super();
        this.Saldo = saldo;
        this.saqueRequerido = saqueRequerido;
    }

    @Override
    public String toString() {
        return "Seu saldo é inferior ao valor do saque requerido!";
    }
}
