package provas.linguagemProgramacao1.provaLP1.exercicio2;

import jdk.swing.interop.SwingInterOpUtils;

import java.sql.SQLOutput;
import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        Random random = new Random();
        int senha, numeroConta, agencia;
        double capital;
        int opcao = 0;
        String nome;
        System.out.println("=-==-=-==-=-==-=-==-=-==-=-==-=-==" +
                           "\n   Bem vindo(a) ao Banco ESUP" +
                           "\n=-==-=-==-=-==-=-==-=-==-=-==-=-==" +
                           "\n\n  Informe os dados a seguir para " +
                           "\n     realização do cadastro");
        System.out.print("\n Nome : ");
        nome = scan.nextLine();
        System.out.print(" Capital inicial: ");
        capital = scan.nextDouble();
        if (capital < 50) {
            System.out.println("Sua conta não foi aprovada.");
            System.exit(0);
        }
        System.out.print(" Informe uma senha com (somente números - 4 dígitos): ");
        senha = scan.nextInt();
        numeroConta = random.nextInt((9999999 - 1000000) + 1) + 1000000;
        agencia = random.nextInt((9999 - 1000) + 1) + 1000;
        Conta conta = new Conta(nome, numeroConta, agencia, capital, senha);
        System.out.println("\n Conta criada com sucesso!" +
                           "\n Conta: " + numeroConta +
                           "\n Agência: " + agencia);
        System.out.println("Deseja prosseguir? (Digite qualquer tecla)");
        String parada = scan.next();

        limparTela();


        while (opcao != 5) {
            System.out.print("Informe a ação que queira efetuar: " +
                    "\n[1] - Saque" +
                    "\n[2] - Depósito" +
                    "\n[3] - Verificar saldo em conta" +
                    "\n[4] - Verificar limite de saque diário disponível" +
                    "\n[5] - Sair" +
                    "\n\n - - -> ");
            opcao = scan.nextInt();
            if (opcao == 1) {
                limparTela();
                Conta.saque(conta);
            }
            if (opcao == 2) {
                limparTela();
                Conta.deposito(conta);
            }
            if (opcao == 3) {
                limparTela();
                System.out.println("\n\n Saldo disponível: R$" + conta.getSaldo()+"\n");
            }
            if (opcao == 4) {
                limparTela();
                System.out.println("\n\nLimite de saque diário disponível: " + conta.getSaqueDiario()+"\n");
            }
        }
        System.out.println("Sistema encerrado.");
    }

    public static void limparTela () {
        System.out.println("\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
    }
}
