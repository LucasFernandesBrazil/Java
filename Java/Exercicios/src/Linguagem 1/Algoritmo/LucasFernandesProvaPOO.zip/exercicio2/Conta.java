package provas.linguagemProgramacao1.provaLP1.exercicio2;

import java.util.Scanner;

public class Conta {
    private String nome;
    private int numeroConta;
    private int agencia;
    private double saldo;
    private double saqueDiario;
    private int senha;

    public Conta (String nome, int numeroConta, int agencia, double saldo, int senha) {
        this.nome = nome;
        this.numeroConta = numeroConta;
        this.agencia = agencia;
        if (saldo > 50) {
            this.saldo = saldo;
        }
        if (saldo < 50) {
            this.saldo = 0;
        }
        this.saqueDiario = 350;
        this.senha = senha;
    }

    public int getNumeroConta() {
        return numeroConta;
    }

    public void setNumeroConta(int numeroConta) {
        this.numeroConta = numeroConta;
    }

    public int getAgencia() {
        return agencia;
    }

    public void setAgencia(int agencia) {
        this.agencia = agencia;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    public double getSaqueDiario() {
        return saqueDiario;
    }

    public void setSaqueDiario(double saqueDiario) {
        this.saqueDiario = saqueDiario;
    }

    public static void saque (Conta conta) {
        Scanner scan = new Scanner (System.in);
        try {
            System.out.print("Informe o valor do saque logo abaixo:" +
                    "\n- - > R$");
            double saqueAcao = scan.nextInt();
            if (saqueAcao > conta.getSaldo()) {
                throw new SaldoEstourado(conta.getSaldo(), saqueAcao);
            }
            if (saqueAcao > conta.saqueDiario) {
                throw new LimiteDeSaqueAtingido(conta.saqueDiario, saqueAcao);
            }
            conta.setSaqueDiario(conta.getSaqueDiario() - saqueAcao);
            conta.setSaldo(conta.getSaldo() - saqueAcao);
            System.out.println("\n\nSaque realizado com sucesso!" +
                    "\n Valor remanescente: R$" + conta.getSaldo()+"\n");
        }
        catch (LimiteDeSaqueAtingido limiteDeSaqueAtingido) {
            System.out.println("\n********************************" +
                               "\nLimite de saque diário atingido!" +
                               "\n       Tente novamente!" +
                               "\n********************************\n");
        }
        catch (SaldoEstourado saldoEstourado) {
            System.out.println("\n***************************************" +
                               "\nValor do saque é maior que seu Saldo" +
                               "\n          Tente novamente!" +
                               "\n***************************************\n");
        }
    }

    public static void deposito (Conta conta) {
        Scanner scan = new Scanner(System.in);
        System.out.print("Informe o valor do deposito logo abaixo:" +
                         "\n- - > R$");
        double depositoAcao = scan.nextInt();
        conta.setSaldo(conta.getSaldo() + depositoAcao);
        System.out.println("\n\nDeposito realizado com sucesso!" +
                           "\n Valor atualizado: R$" + conta.getSaldo()+"\n");
    }
}
