package provas.linguagemProgramacao1.provaLP1.exercicio4;


public class Main {
    public static void main(String[] args) {
        JogoDaVelha jogoDaVelha = new JogoDaVelha();
        jogoDaVelha.executar();
    }
}
