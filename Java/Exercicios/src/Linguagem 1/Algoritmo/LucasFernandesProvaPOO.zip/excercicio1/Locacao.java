package provas.linguagemProgramacao1.provaLP1.excercicio1;

public class Locacao {
    private Filme filme;
    public Locacao (Filme filme){
        this.filme = filme;
    }
    public Filme getFilme() {
        return filme;
    }
    public void setFilme(Filme filme) {
        this.filme = filme;
    }
}
