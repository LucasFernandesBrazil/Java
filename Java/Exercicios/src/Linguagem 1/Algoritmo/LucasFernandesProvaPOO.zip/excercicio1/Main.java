package provas.linguagemProgramacao1.provaLP1.excercicio1;

import carrinho.Categoria;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.print("==-=-==-=-==-= LOCADORA ESUP =-==-=-==-=-==" +
                "\nInforme o filme a ser locado: ");
        String nomeFilme = scan.next();
        Filme AnnaBelle = new Filme(nomeFilme);
        AnnaBelle.setAnoLancamento(2018);
        AnnaBelle.setCategoriaFilme(CategoriaFilme.LANCAMENTO);
        AnnaBelle.setDescricao("Boneca assassina que quer matar todos");
        AnnaBelle.setDuracaoMinutos(140);
        AnnaBelle.setPreco(22.50);
        System.out.println("Ano de lançamento: " + AnnaBelle.getAnoLancamento() +
                "\nCategoria: " + AnnaBelle.getCategoriaFilme()+
                "\nDescrição: " + AnnaBelle.getDescricao() +
                "\nDuração em minutos: " + AnnaBelle.getDuracaoMinutos() +
                "\nValor: R$" + AnnaBelle.getPreco());
        Locacao locacao = new Locacao(AnnaBelle);
        System.out.println("Filme locado com sucesso!");

    }
}
