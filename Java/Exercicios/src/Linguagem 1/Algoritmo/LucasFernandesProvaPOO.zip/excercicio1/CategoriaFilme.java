package provas.linguagemProgramacao1.provaLP1.excercicio1;

public enum CategoriaFilme {
    LANCAMENTO, CATALOGO;
}
