package provas.linguagemProgramacao1.provaLP1.exercicio3;

public class Autor extends Pessoa{
    private int codigo;

    public Autor() {
        this.codigo = codigo;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }
}
