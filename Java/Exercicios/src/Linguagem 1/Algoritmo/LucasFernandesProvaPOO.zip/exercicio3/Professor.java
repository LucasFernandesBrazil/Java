package provas.linguagemProgramacao1.provaLP1.exercicio3;

public class Professor extends Pessoa{
    private int registro;
    private Titulo titulo;
    private Disciplina disciplina;
    private int numeroDeDisciplinas;

    public Professor(int numeroDeDisciplinas) {
        this.registro = registro;
        this.titulo = null;
        this.disciplina = null;
        this.numeroDeDisciplinas = numeroDeDisciplinas;
    }

    public int getRegistro() {
        return registro;
    }

    public void setRegistro(int registro) {
        this.registro = registro;
    }

    public Titulo getTitulo() {
        return titulo;
    }

    public void setTitulo(Titulo titulo) {
        this.titulo = titulo;
    }

    public int getNumeroDeDisciplinas() {
        return numeroDeDisciplinas;
    }

    public void setNumeroDeDisciplinas(int numeroDeDisciplinas) {
        this.numeroDeDisciplinas = numeroDeDisciplinas;
    }

    public Disciplina getDisciplina() {
        return disciplina;
    }

    public int setDisciplina(Disciplina disciplina) {
        this.disciplina = disciplina;
        return 0;
    }
}
