package provas.linguagemProgramacao1.provaLP1.exercicio3;

public enum Titulo {
    ESPECIALISTA, MESTRE, DOUTOR
}
