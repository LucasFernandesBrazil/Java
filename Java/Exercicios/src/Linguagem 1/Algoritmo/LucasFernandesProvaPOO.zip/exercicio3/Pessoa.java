package provas.linguagemProgramacao1.provaLP1.exercicio3;

public class Pessoa {
    protected String nome;
    protected String endereco;
    protected String email;
    protected Genero genero;

    public Pessoa () {
        this.nome = null;
        this.endereco = null;
        this.email = null;
        this.genero = null;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Genero getGenero() {
        return genero;
    }

    public void setGenero(Genero genero) {
        this.genero = genero;
    }
}
