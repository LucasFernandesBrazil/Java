package provas.linguagemProgramacao1.provaLP1.exercicio3;

import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        Autor stevenLay = new Autor();
        stevenLay.setNome("Steven R. Lay");
        stevenLay.setGenero(Genero.MASCULINO);
        stevenLay.setEndereco("68927-293");
        stevenLay.setEmail("StevenR@hotmail.com");
        stevenLay.setCodigo(42342);

        Livro algebraLinear = new Livro();
        algebraLinear.setTitulo("Álgebra linear e suas aplicações");
        algebraLinear.setAutor(stevenLay);
        algebraLinear.setDescricao(" Álgebra Linear e Suas Aplicações é um clássico do ensino de Matemática. Está vinculado ao que há de mais contemporâneo e inovador quanto à pedagogia e à didática voltadas para o aprendizado, conforme as recomendações do Linear Algebra Curriculum Study Group, nos Estados Unidos.");

        Livro algebraExercicios = new Livro();
        algebraExercicios.setTitulo("Álgebra linear - Exercícios");
        algebraExercicios.setAutor(stevenLay);
        algebraExercicios.setDescricao("Exercícios de aplicação para a Álgebra Linear - Nivel Ensino Médio");

        Disciplina algebra = new Disciplina();
        algebra.setNome("Álgebra");
        algebra.setDescricao("Matéria com o dever de ensinar Álgebra");
        algebra.setLivro1(algebraLinear);
        algebra.setLivro2(algebraExercicios);

        Disciplina algebra2 = new Disciplina();
        algebra.setNome("Álgebra 2");
        algebra.setDescricao("Matéria com o dever de ensinar Álgebra");
        algebra.setLivro1(algebraLinear);
        algebra.setLivro2(algebraExercicios);

        Professor DrLuis = new Professor(2);
        DrLuis.setNome("Luis Carlos Urzêda");
        int disciplinas[] = new int[DrLuis.getNumeroDeDisciplinas()];
        disciplinas [0] = DrLuis.setDisciplina(algebra);
        disciplinas [1] = DrLuis.setDisciplina(algebra2);
        DrLuis.setDisciplina(algebra);
        DrLuis.setRegistro(637251);
        DrLuis.setTitulo(Titulo.DOUTOR);
        DrLuis.setEmail("LuisProfessor@gmail.com");
        DrLuis.setEndereco("72847-538");
        DrLuis.setGenero(Genero.MASCULINO);


        Turma sextoA = new Turma();
        sextoA.setCodigo(432764);
        sextoA.setDiaSemana(DiaSemana.QUARTA);
        sextoA.setDisciplina(algebra);
        sextoA.setHorario("08:30");
        sextoA.quantidadeAlunos(5);

        Aluno lucasFernandes = new Aluno();
        lucasFernandes.setNome("Lucas Fernandes");
        lucasFernandes.setMatricula("1413-3");
        lucasFernandes.setTurma(sextoA);
        lucasFernandes.setEmail("LucasFernandes@gmail.com");
        lucasFernandes.setEndereco("89920-345");
        lucasFernandes.setGenero(Genero.MASCULINO);

    }
}
