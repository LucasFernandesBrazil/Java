package provas.linguagemProgramacao1.provaLP1.exercicio3;

public enum Genero {
    MASCULINO, FEMININO
}
