package provas.linguagemProgramacao1.provaLP1.exercicio3;

public class Disciplina {
    private String nome;
    private String descricao;
    private Livro livro1;
    private Livro livro2;

    public Disciplina() {
        this.nome = null;
        this.descricao = null;
        this.livro1 = null;
        this.livro2 = null;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public Livro getLivro1() {
        return livro1;
    }

    public void setLivro1(Livro livro1) {
        this.livro1 = livro1;
    }

    public Livro getLivro2() {
        return livro2;
    }

    public void setLivro2(Livro livro2) {
        this.livro2 = livro2;
    }
}
