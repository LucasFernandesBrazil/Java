package provas.linguagemProgramacao1.provaLP1.exercicio3;

public class Turma {
    private int codigo;
    private Disciplina disciplina;
    private String [] listaDeAlunos;
    private String horario;
    private DiaSemana diaSemana;

    public Turma() {
        this.codigo = 0;
        this.disciplina = null;
        this.listaDeAlunos = null;
        this.horario = null;
        this.diaSemana = null;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public Disciplina getDisciplina() {
        return disciplina;
    }

    public void setDisciplina(Disciplina disciplina) {
        this.disciplina = disciplina;
    }

    public String[] getListaDeAlunos() {
        return listaDeAlunos;
    }

    public void setListaDeAlunos(String[] listaDeAlunos) {
        this.listaDeAlunos = listaDeAlunos;
    }

    public String getHorario() {
        return horario;
    }

    public void setHorario(String horario) {
        this.horario = horario;
    }

    public DiaSemana getDiaSemana() {
        return diaSemana;
    }

    public void setDiaSemana(DiaSemana diaSemana) {
        this.diaSemana = diaSemana;
    }
    public String [] quantidadeAlunos (int x) {
        return this.listaDeAlunos = new String[x];
    }


}
