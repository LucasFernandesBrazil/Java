package provas.linguagemProgramacao1.provaLP1.exercicio3;

public enum DiaSemana {
    SEGUNDA, TERCA, QUARTA, QUINTA, SEXTA, SABADO
}
