package provas.linguagemProgramacao1.provaLP1.exercicio3;

public class Livro {
    private String titulo;
    private String descricao;
    private Autor autor;

    public Livro() {
        this.titulo = null;
        this.descricao = null;
        this.autor = null;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public Autor getAutor() {
        return autor;
    }

    public void setAutor(Autor autor) {
        this.autor = autor;
    }
}
